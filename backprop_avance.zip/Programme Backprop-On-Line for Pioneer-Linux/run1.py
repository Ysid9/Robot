from BackProp_Python_v2 import NN
from vrep_pioneer_simulation import VrepPioneerSimulation
#from rdn import Pioneer # rdn pour ROS avec le pioneer
#import rospy
from online_trainer import OnlineTrainer
import json
import threading
import time
import os

print("Starting run.py")
print(f"Current working directory: {os.getcwd()}")

try:
    # Initialize robot simulation
    print("Initializing robot simulation...")
    robot = VrepPioneerSimulation()
    
    # Check if connection was established
    if robot.client_id == -1:
        print("Failed to connect to CoppeliaSim. Exiting...")
        exit(1)
        
    print("Initializing neural network...")
    HL_size = 9  # nbre neurons of Hidden layer
    network = NN(3, HL_size, 2)

    choice = input('Do you want to load previous network? (y/n) --> ')
    if choice.lower() == 'y':
        try:
            print("Loading network weights from last_w.json...")
            with open('last_w.json') as fp:
                json_obj = json.load(fp)

            for i in range(3):
                for j in range(HL_size):
                    network.wi[i][j] = json_obj["input_weights"][i][j]
            for i in range(HL_size):
                for j in range(2):
                    network.wo[i][j] = json_obj["output_weights"][i][j]
            print("Network weights loaded successfully")
        except FileNotFoundError:
            print("WARNING: last_w.json not found. Starting with random weights.")
        except json.JSONDecodeError:
            print("WARNING: Error parsing last_w.json. Starting with random weights.")
        except Exception as e:
            print(f"WARNING: Unexpected error loading weights: {e}. Starting with random weights.")

    print("Creating online trainer...")
    trainer = OnlineTrainer(robot, network)

    choice = ''
    while choice.lower() not in ['y', 'n']:
        choice = input('Do you want to learn? (y/n) --> ')

    if choice.lower() == 'y':
        trainer.training = True
        print("Learning mode enabled")
    elif choice.lower() == 'n':
        trainer.training = False
        print("Learning mode disabled")

    target_input = input("Enter the first target : x y radian --> ")
    target = target_input.split()
    try:
        for i in range(len(target)):
            target[i] = float(target[i])
        print(f'New target: [{target[0]}, {target[1]}, {target[2]}]')
    except (ValueError, IndexError) as e:
        print(f"Error parsing target coordinates: {e}")
        print("Using default target [0, 0, 0]")
        target = [0.0, 0.0, 0.0]

    print("Getting current robot position...")
    current_position = robot.get_position()
    print(f"Current position: {current_position}")

    continue_running = True
    while(continue_running):
        print(f"Starting training thread with target {target}")
        
        # Set running flag before starting thread
        trainer.running = True
        
        thread = threading.Thread(target=trainer.train, args=(target,))
        thread.start()
        print("Training thread started")

        # Ask for stop running
        input("Press Enter to stop the current training")
        print("Stopping training...")
        trainer.running = False
        print("Waiting for training thread to finish...")
        thread.join()
        print("Training thread finished")
        
        choice = ''
        while choice.lower() not in ['y', 'n']:
            choice = input("Do you want to continue? (y/n) --> ")

        if choice.lower() == 'y':
            choice_learning = ''
            while choice_learning.lower() not in ['y', 'n']:
                choice_learning = input('Do you want to learn? (y/n) --> ')
            if choice_learning.lower() == 'y':
                trainer.training = True
                print("Learning mode enabled")
            elif choice_learning.lower() == 'n':
                trainer.training = False
                print("Learning mode disabled")
                
            target_input = input("Move the robot to the initial point and enter the new target : x y radian --> ")
            target = target_input.split()
            try:
                for i in range(len(target)):
                    target[i] = float(target[i])
                print(f'New target: [{target[0]}, {target[1]}, {target[2]}]')
            except (ValueError, IndexError) as e:
                print(f"Error parsing target coordinates: {e}")
                print("Using previous target")
        elif choice.lower() == 'n':
            continue_running = False

    print("Saving weights to last_w.json...")
    json_obj = {"input_weights": network.wi, "output_weights": network.wo}
    with open('last_w.json', 'w') as fp:
        json.dump(json_obj, fp)

    print("The last weights have been stored in last_w.json")
    
except Exception as e:
    print(f"An unexpected error occurred: {e}")
    import traceback
    traceback.print_exc()