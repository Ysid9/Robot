from pytorch_BackProp_v1 import PytorchNN
from pytorch_pioneer_simulation import ZMQPioneerSimulation
from pytorch_online_trainer import PyTorchOnlineTrainer
import json
import threading
import atexit
import time
import torch

# Check if PyTorch is available and using CUDA if available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"PyTorch is using: {device}")

# Initialize the robot with ZMQ Remote API
robot = ZMQPioneerSimulation()

# Register cleanup function to ensure simulation is stopped
def cleanup():
    print("Cleaning up and stopping simulation...")
    if hasattr(robot, 'cleanup'):
        robot.cleanup()
atexit.register(cleanup)

# Wait a moment to ensure the simulation is fully started
time.sleep(1)

# Neural network configuration
input_size = 3  # Error in x, y, theta
hidden_size = 10  # Number of neurons in hidden layer
output_size = 2  # Velocities for left and right wheels

# Create PyTorch neural network
network = PytorchNN(input_size, hidden_size, output_size)
network.to(device)  # Move to GPU if available
print(f"Created neural network with architecture: {input_size}-{hidden_size}-{output_size}")

# Ask user if they want to load previous weights
choice = input('Do you want to load previous network? (y/n) --> ')
if choice.lower() == 'y':
    try:
        with open('last_w.json') as fp:
            json_obj = json.load(fp)
        
        # Load weights into PyTorch model
        network.load_weights(json_obj)
        print("✅ Network weights loaded successfully")
    except Exception as e:
        print(f"❌ Error loading weights: {e}")
        print("Starting with a new network")

# Create trainer instance
trainer = PyTorchOnlineTrainer(robot, network)

# Set learning mode
choice = ''
while choice.lower() not in ['y', 'n']:
    choice = input('Do you want to learn? (y/n) --> ')

trainer.training = (choice.lower() == 'y')
print(f"Learning mode: {'ON' if trainer.training else 'OFF'}")

# Get initial target from user
target_input = input("Enter the first target : x y radian --> ")
try:
    target = [float(val) for val in target_input.split()]
    print(f'✅ New target set: [{target[0]:.2f}, {target[1]:.2f}, {target[2]:.2f}]')
except Exception as e:
    print(f"❌ Error parsing target: {e}")
    print("Using default target [0, 0, 0]")
    target = [0, 0, 0]

# Main training loop
continue_running = True
while continue_running:
    # Start training in a separate thread
    thread = threading.Thread(target=trainer.train, args=(target,))
    trainer.running = True
    thread.start()

    # Wait for user to stop training
    input("Press Enter to stop the current training")
    trainer.running = False
    
    # Wait for the thread to finish with a timeout
    thread.join(timeout=5)
    if thread.is_alive():
        print("⚠️ Training thread did not finish in time, but we'll continue")
    
    # Ask user if they want to continue
    choice = ''
    while choice.lower() not in ['y', 'n']:
        choice = input("Do you want to continue? (y/n) --> ")

    if choice.lower() == 'y':
        # Ask if user wants to continue learning
        choice_learning = ''
        while choice_learning.lower() not in ['y', 'n']:
            choice_learning = input('Do you want to learn? (y/n) --> ')
        trainer.training = (choice_learning.lower() == 'y')
        
        # Get new target
        target_input = input("Move the robot to the initial point and enter the new target : x y radian --> ")
        try:
            target = [float(val) for val in target_input.split()]
            print(f'✅ New target set: [{target[0]:.2f}, {target[1]:.2f}, {target[2]:.2f}]')
        except Exception as e:
            print(f"❌ Error parsing target: {e}")
            print("Keeping previous target")
    else:
        continue_running = False

# Save the weights
try:
    json_obj = network.save_weights()
    with open('last_w.json', 'w') as fp:
        json.dump(json_obj, fp)
    print("✅ The last weights have been stored in last_w.json")
except Exception as e:
    print(f"❌ Error saving weights: {e}")

# Final cleanup
cleanup()