import torch
import torch.nn as nn
import torch.optim as optim
import math
import random

class PytorchNN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        """
        PyTorch implementation of a neural network for online learning.
        
        Args:
            input_size (int): Size of input layer
            hidden_size (int): Size of hidden layer
            output_size (int): Size of output layer
        """
        super(PytorchNN, self).__init__()
        
        # Define network architecture
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        
        # Define layers
        self.hidden_layer = nn.Linear(input_size, hidden_size)
        self.output_layer = nn.Linear(hidden_size, output_size)
        
        # Initialize weights with uniform distribution between -1 and 1
        # to match the original implementation
        nn.init.uniform_(self.hidden_layer.weight, -1.0, 1.0)
        nn.init.uniform_(self.output_layer.weight, -1.0, 1.0)
        nn.init.zeros_(self.hidden_layer.bias)
        nn.init.zeros_(self.output_layer.bias)
        
        # Initialize activation function
        self.activation = nn.Tanh()
        
        # Store last inputs, hidden outputs, and outputs for gradient calculation
        self.last_inputs = None
        self.last_hidden_outputs = None
        self.last_outputs = None
        
    def forward(self, x):
        """
        Forward pass through the network
        
        Args:
            x (Tensor): Input tensor of shape (input_size,)
            
        Returns:
            Tensor: Output tensor of shape (output_size,)
        """
        # Convert input to tensor if it's not already
        if not isinstance(x, torch.Tensor):
            x = torch.tensor(x, dtype=torch.float32)
        
        # Reshape if needed
        if x.dim() == 1:
            x = x.unsqueeze(0)  # Add batch dimension
            
        # Store inputs for backpropagation
        self.last_inputs = x
        
        # Forward pass
        hidden = self.hidden_layer(x)
        hidden_activated = self.activation(hidden)
        self.last_hidden_outputs = hidden_activated
        
        output = self.output_layer(hidden_activated)
        output_activated = self.activation(output)
        self.last_outputs = output_activated
        
        # Return as list for compatibility with original code
        return output_activated.squeeze().tolist()
    
    def run_nn(self, inputs):
        """
        Compatibility method with the original NN class
        
        Args:
            inputs (list): Input values
            
        Returns:
            list: Output values
        """
        with torch.no_grad():
            return self.forward(inputs)
    
    def backpropagate(self, grad, learning_rate, momentum):
        """
        Custom backpropagation implementation for online learning.
        
        Args:
            grad (list): Gradient of the cost function with respect to outputs
            learning_rate (float): Learning rate
            momentum (float): Momentum factor
            
        Returns:
            bool: Always False for compatibility with original code
        """
        # Convert grad to tensor if it's not already
        if not isinstance(grad, torch.Tensor):
            grad = torch.tensor(grad, dtype=torch.float32)
            
        # Reshape if needed
        if grad.dim() == 1:
            grad = grad.unsqueeze(0)  # Add batch dimension
        
        # Enable autograd
        self.zero_grad()
        
        # Manually compute gradients by directly applying the gradients
        # to the outputs (similar to how the original implementation works)
        
        # Get the derivative of tanh for output layer
        d_output = 1 - self.last_outputs ** 2  # Derivative of tanh
        
        # Apply the custom gradient to the outputs
        # Chain rule: gradient * derivative of activation
        delta_output = grad * d_output.squeeze()
        
        # Create a dummy loss that, when backpropagated, will apply our custom gradient
        dummy_loss = torch.sum(self.last_outputs.squeeze() * delta_output)
        dummy_loss.backward()
        
        # Apply the gradients with the learning rate and momentum
        with torch.no_grad():
            for param in self.parameters():
                if param.grad is not None:
                    # Apply learning rate
                    param.data.add_(param.grad.data, alpha=-learning_rate)
        
        return False
    
    def random_update(self, random_ratio):
        """
        Randomly update weights by a small amount
        
        Args:
            random_ratio (float): Maximum ratio of weight change
        """
        with torch.no_grad():
            for param in self.parameters():
                # Maximum perturbation is relative to current weight
                max_perturbation = random_ratio * param.data
                # Generate random perturbations
                perturbation = torch.rand_like(param.data) * 2 - 1  # [-1, 1]
                perturbation *= max_perturbation
                # Apply perturbation
                param.data.add_(perturbation)
    
    def save_weights(self):
        """
        Extract weights in a format compatible with the original code
        
        Returns:
            dict: Dictionary with input_weights and output_weights
        """
        with torch.no_grad():
            # Extract input to hidden weights (wi)
            wi = self.hidden_layer.weight.data.t().tolist()  # Transpose to match original format
            
            # Extract hidden to output weights (wo)
            wo = self.output_layer.weight.data.t().tolist()  # Transpose to match original format
            
            return {"input_weights": wi, "output_weights": wo}
    
    def load_weights(self, weights_dict):
        """
        Load weights from a format compatible with the original code
        
        Args:
            weights_dict (dict): Dictionary with input_weights and output_weights
        """
        with torch.no_grad():
            # Load input to hidden weights (wi)
            wi = torch.tensor(weights_dict["input_weights"], dtype=torch.float32).t()
            self.hidden_layer.weight.data.copy_(wi)
            
            # Load hidden to output weights (wo)
            wo = torch.tensor(weights_dict["output_weights"], dtype=torch.float32).t()
            self.output_layer.weight.data.copy_(wo)

# Original utility functions maintained for compatibility
def makeMatrix(I, J, fill=0.0):
    m = []
    for i in range(I):
        m.append([fill]*J)
    return m

def randomizeMatrix(matrix, a, b):
    for i in range(len(matrix)):
        for j in range(len(matrix[0])):
            matrix[i][j] = random.uniform(a, b)