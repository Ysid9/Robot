import time
import math
import torch

def theta_s(x, y):
    """
    Strategy function to avoid local minima.
    This function is used to modify the target orientation.
    
    Args:
        x (float): X coordinate
        y (float): Y coordinate
        
    Returns:
        float: Modified theta
    """
    # Original strategy
    # if x > 0:
    #     return 1 * math.atan(1 * y)
    # if x <= 0:
    #     return 1 * math.atan(-1 * y)
    
    # Improved strategy with smoother transition
    return math.tanh(10. * x) * math.atan(1. * y)

class PyTorchOnlineTrainer:
    def __init__(self, robot, network):
        """
        Online trainer using PyTorch for neural network learning.
        
        Args:
            robot (Robot): Robot instance (ZMQPioneerSimulation)
            network (PytorchNN): PyTorch neural network instance
        """
        self.robot = robot
        self.network = network
        self.running = False
        self.training = False
        
        # Normalization factors to scale inputs to the neural network
        # Cartesian world limits approximately -3m to +3m
        self.alpha = [1/6, 1/6, 1/(math.pi)]
        
        # Learning hyperparameters
        self.learning_rate = 0.2
        self.momentum = 0.0
        self.random_noise_ratio = 0.001
        
    def train(self, target):
        """
        Main training loop for online learning.
        
        Args:
            target (list): Target position [x, y, theta]
        """
        # Get initial position
        position = self.robot.get_position()
        
        # Calculate error and normalize inputs
        network_input = [0, 0, 0]
        network_input[0] = (position[0] - target[0]) * self.alpha[0]
        network_input[1] = (position[1] - target[1]) * self.alpha[1]
        network_input[2] = (position[2] - target[2] - theta_s(position[0], position[1])) * self.alpha[2]
        
        # Main training loop
        while self.running:
            # Record start time for delta_t calculation
            debut = time.time()
            
            # Forward pass - calculate wheel velocities from error
            command = self.network.run_nn(network_input)
            
            # Cost function parameters
            alpha_x = 1/6
            alpha_y = 1/6
            alpha_teta = 1.0/(math.pi)
            
            # Calculate cost before movement
            crit_av = (
                alpha_x**2 * (position[0] - target[0])**2 + 
                alpha_y**2 * (position[1] - target[1])**2 + 
                alpha_teta**2 * (position[2] - target[2] - theta_s(position[0], position[1]))**2
            )
            
            # Apply command to robot
            self.robot.set_motor_velocity(command)
            
            # Small delay for simulation step
            time.sleep(0.050)
            
            # Get new position after movement
            position = self.robot.get_position()
            
            # Recalculate error for next step
            network_input[0] = (position[0] - target[0]) * self.alpha[0]
            network_input[1] = (position[1] - target[1]) * self.alpha[1]
            network_input[2] = (position[2] - target[2] - theta_s(position[0], position[1])) * self.alpha[2]
            
            # Calculate cost after movement
            crit_ap = (
                alpha_x**2 * (position[0] - target[0])**2 + 
                alpha_y**2 * (position[1] - target[1])**2 + 
                alpha_teta**2 * (position[2] - target[2] - theta_s(position[0], position[1]))**2
            )
            
            # Only update weights if in training mode
            if self.training:
                # Calculate time delta for gradient
                delta_t = (time.time() - debut)
                
                # Calculate gradient of cost function with respect to wheel velocities
                grad = [
                    (-2/delta_t) * (
                        alpha_x**2 * (position[0] - target[0]) * delta_t * self.robot.r * math.cos(position[2]) +
                        alpha_y**2 * (position[1] - target[1]) * delta_t * self.robot.r * math.sin(position[2]) -
                        alpha_teta**2 * (position[2] - target[2] - theta_s(position[0], position[1])) * delta_t * self.robot.r / (2 * self.robot.R)
                    ),
                    (-2/delta_t) * (
                        alpha_x**2 * (position[0] - target[0]) * delta_t * self.robot.r * math.cos(position[2]) +
                        alpha_y**2 * (position[1] - target[1]) * delta_t * self.robot.r * math.sin(position[2]) +
                        alpha_teta**2 * (position[2] - target[2] - theta_s(position[0], position[1])) * delta_t * self.robot.r / (2 * self.robot.R)
                    )
                ]
                
                # If cost function decreased, apply gradient descent
                # Otherwise, apply random noise to escape local minimum
                if crit_ap <= crit_av:
                    self.network.backpropagate(grad, self.learning_rate, self.momentum)
                else:
                    # Option 1: Apply random noise
                    # self.network.random_update(self.random_noise_ratio)
                    
                    # Option 2: Continue with gradient descent even when cost increases
                    self.network.backpropagate(grad, self.learning_rate, self.momentum)
        
        # Stop motors when training is finished
        self.robot.set_motor_velocity([0, 0])
        
        # Set running flag to false
        self.running = False